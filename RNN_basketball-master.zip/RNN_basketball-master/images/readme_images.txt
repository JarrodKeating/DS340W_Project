Convention for the cleaned images and videos
- Hits: Blue colored
- Misses: Red colored

0-based indexing
- label = 0: Hit
- label = 1: Miss

1-based indexing
- label = 1: Hit
- label = 2: Miss
